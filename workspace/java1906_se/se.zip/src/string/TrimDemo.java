package string;

/**
 * 
 * String trim() 去除当前字符串中的空白字符
 * 
 * 
 * @author tarena
 *
 */

public class TrimDemo {

	public static void main(String[] args) {
		String str = "    Hello     a";

		System.out.println(str.trim());

	}
}
